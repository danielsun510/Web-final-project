package com.infsci.servlet;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Good;
import com.infsci.dao.GoodDao;

public class FPageEmpServlet extends HttpServlet {

	private GoodDao goodDao = new GoodDao();

	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
    
		Good commendgood= new Good();
		Good newgood = new Good();
		Good populargood = new Good();
		
		commendgood = goodDao.getGoodById(1010);
		newgood= goodDao.getGoodByDate();
		populargood=goodDao.getGoodByAmount();
		
		
		request.setAttribute("commendgood", commendgood);
		request.setAttribute("newgood", newgood);
		request.setAttribute("populargood", populargood);
		

		request.getRequestDispatcher("Front_Home.jsp").forward(request, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}

}
