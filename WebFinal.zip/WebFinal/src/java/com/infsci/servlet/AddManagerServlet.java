package com.infsci.servlet;


import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Manager;
import com.infsci.dao.ManagerDAO;

public class AddManagerServlet extends HttpServlet {

	private ManagerDAO managerDao = new ManagerDAO();

	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		//
		request.setCharacterEncoding("utf-8");
		String uname = request.getParameter("u_name");
		String upass = request.getParameter("u_pass");	

		try {
			Manager manager = new Manager(uname,upass);
			boolean b = managerDao.addManager(manager);
			if (b) {
				request.setAttribute("msg", "Add Manager successfully!");
			} else {
				request.setAttribute("msg", "Fail to add Manager!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "opppssss!");
		}

		request.getRequestDispatcher("Sys_Addmanager.jsp").forward(request, resp);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(request, resp);
	}

}
