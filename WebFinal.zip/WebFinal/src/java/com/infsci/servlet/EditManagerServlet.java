package com.infsci.servlet;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Manager;
import com.infsci.dao.ManagerDAO;

public class EditManagerServlet extends HttpServlet {
	
	private ManagerDAO managerDao = new ManagerDAO();
	
	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		
		List<Manager> managerList = managerDao.getManagerList();
		request.setAttribute("managerList", managerList);
		
		request.getRequestDispatcher("Sys_Deletemanager.jsp").forward(request, resp);
		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

	}

	
	
}