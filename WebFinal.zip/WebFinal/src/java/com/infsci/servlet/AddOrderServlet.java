package com.infsci.servlet;


import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Order;
import com.infsci.dao.OrderDao;

public class AddOrderServlet extends HttpServlet {

	private OrderDao orderDao = new OrderDao();

	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		//
		request.setCharacterEncoding("utf-8");
		String p_id = request.getParameter("p_id");
		String c_id = request.getParameter("c_id");
		String o_amount=request.getParameter("quantity");

		String Nowtime=new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());

		try {

			Date p_date = Date.valueOf(Nowtime);
			request.setAttribute("c_id", c_id);

			Order order = new Order(Integer.parseInt(c_id),Integer.parseInt(p_id),Integer.parseInt(o_amount),p_date);
			int num =orderDao.getAmount(order);
			
			
			if(num>=Integer.parseInt(o_amount)){
				
			boolean b = orderDao.addOrder(order);
			
			
			if (b) {
				request.setAttribute("msg", "Add order successfully!");
			} else {
				request.setAttribute("msg", "Fail to add order!");
			}
			
			}else{
				
				request.setAttribute("msg", "Fail to add order! No enough products!");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "opppssss!");
		}

		request.getRequestDispatcher("OrderPageEmp?page=1").forward(request, resp);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(request, resp);
	}

}
