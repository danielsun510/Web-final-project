package com.infsci.servlet;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Order;
import com.infsci.dao.OrderDao;

public class OrderPageEmpServlet extends HttpServlet {

	private static final int PAGEROW = 20;
	private OrderDao orderDao = new OrderDao();
	private String c_id;

	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {

		int page = 1;
		c_id =  (String)request.getAttribute("c_id");
		System.out.println(c_id);
		String str_page = request.getParameter("page");
		if (str_page != null) {
			page = Integer.parseInt(str_page);
		}
		int orderCount = orderDao.getOrderCount();
		int pageCount = (orderCount % PAGEROW) == 0 ? (orderCount / PAGEROW)
				: (orderCount / PAGEROW + 1);

		if (page < 1) {
			page = 1;
		}
		if(page > pageCount){
			page = pageCount;
		}
		
		List<Order> orderList = orderDao.getOrderByO_ID(page, PAGEROW,Integer.parseInt(c_id));
		
		
		request.setAttribute("orderList", orderList);
		request.setAttribute("nowPage", page);
		request.setAttribute("endPage", pageCount);
		request.setAttribute("c_id", c_id);

		request.getRequestDispatcher("Front_Myorder.jsp").forward(request, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}

}
