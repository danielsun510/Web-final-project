package com.infsci.servlet;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Good;
import com.infsci.bean.Member;
import com.infsci.dao.GoodDao;
import com.infsci.dao.Member_LoginDao;

public class PageBZCustomerServlet extends HttpServlet {

	private static final int PAGEROW = 11;
	private Member_LoginDao member_logindao = new Member_LoginDao();

	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {

		int page = 1;

		String str_page = request.getParameter("page");
		if (str_page != null) {
			page = Integer.parseInt(str_page);
		}
		int customerCount = member_logindao.getBZCustomerCount();
		System.out.println(customerCount);
		int pageCount = (customerCount % PAGEROW) == 0 ? (customerCount / PAGEROW)
				: (customerCount / PAGEROW + 1);

		if (page < 1) {
			page = 1;
		}
		if(page > pageCount){
			page = pageCount;
		}
		
		List<Member> memberList = member_logindao.getBZCustomerByPage(page, PAGEROW);
		
		
		request.setAttribute("memberList", memberList);
		request.setAttribute("nowPage", page);
		request.setAttribute("endPage", pageCount);
		System.out.println(page+"---"+pageCount);
		request.getRequestDispatcher("Sys_EditBZcustomer.jsp").forward(request, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}

}
