package com.infsci.servlet;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.bean.Good;
import com.infsci.dao.GoodDao;

public class ChangeTheGoodServlet extends HttpServlet {

	private GoodDao goodDao = new GoodDao();

	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		//
		request.setCharacterEncoding("utf-8");
		String p_id1=request.getParameter("p_id");
		String p_name = request.getParameter("p_name");
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		String day = request.getParameter("day");
		String p_kind=request.getParameter("p_kind");
		String p_price1 = request.getParameter("p_price");
		String p_amount1=request.getParameter("p_amount");
		String p_pic=request.getParameter("p_pic");
		String p_descrip=request.getParameter("p_descrip");

		String indate = year+"-"+month+"-"+day;

		try {

			Date p_date = Date.valueOf(indate);
			int p_price = Integer.parseInt(p_price1);
			int p_amount = Integer.parseInt(p_amount1);
			int p_id=Integer.parseInt(p_id1);

			Good good = new Good(p_id,p_name,p_kind,p_price,p_date,p_amount,p_pic,p_descrip);
			boolean b = goodDao.changeGood(good);
			if (b) {
				request.setAttribute("msg", "Change information successfully!");
			} else {
				request.setAttribute("msg", "Fail to change information!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "opppssss!");
		}

		request.getRequestDispatcher("Sys_Changegood.jsp").forward(request, resp);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(request, resp);
	}

}
