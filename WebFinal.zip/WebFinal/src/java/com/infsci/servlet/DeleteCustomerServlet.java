package com.infsci.servlet;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infsci.dao.Member_LoginDao;

public class DeleteCustomerServlet extends HttpServlet {

	private Member_LoginDao member_logindao = new Member_LoginDao();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String[] p_ids =request.getParameterValues("nos"); //��Ӧ��ѡ��Ĵ�ֵ
		
		if(p_ids!= null && p_ids.length > 0){
			List<Integer> p_idList = new ArrayList<Integer>();
			for(String no : p_ids){
				p_idList.add(Integer.parseInt(no));
			}
			
			member_logindao.deleteCustomer(p_idList);
			
		}

		response.sendRedirect("PageCustomer?page=1");
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

	
	
}
