package com.infsci.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Check_m_nameDao {
	
	public static boolean Check_m_name(String m_name){
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		boolean flag = false;
		try {
			conn = DBConnection.getConnection();
			String sql = "select h_name from tb_home_ctm where h_name = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, m_name);
			rs = ps.executeQuery();
			if(rs.next()){
				
				flag = true;
			}
			
			String sql1 = "select b_name from tb_buz_ctm where b_name = ?";
			ps1 = conn.prepareStatement(sql1);
			ps1.setString(1, m_name);
			rs1 = ps.executeQuery();
			if(rs1.next()){
				flag = true;
			}
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			DBConnection.free(rs, ps, conn);
		}
		return flag;
	}
}
