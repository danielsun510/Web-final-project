package com.infsci.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.infsci.bean.Good;
import com.infsci.bean.Manager;

public class ManagerDAO {
	
	//login
		public boolean login(String username ,int password){
			boolean b = false;
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			
			try{
				
				conn = DBConnection.getConnection();
				String sql = "select uname , upass from tb_manager where uname=? and upass=?";
				ps = conn.prepareStatement(sql);
				ps.setString(1,username);
				ps.setInt(2, password);
				rs=ps.executeQuery();
				
				if(rs.next()){
					b=true;
				}
			}catch(ClassNotFoundException e){
				e.printStackTrace();
				
			}catch(SQLException e){
				e.printStackTrace();
			}finally{
				DBConnection.free(rs, ps, conn);
			}
			
			return b;
			
		}
		public static boolean Check_mgr_name(String uname){
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			boolean flag = false;
			try {
				conn = DBConnection.getConnection();
				String sql = "select uname from tb_manager where uname = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, uname);
				rs = ps.executeQuery();
				if(rs.next()){
					//���ҵõ�˵���ظ�
					flag = true;
				}
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}finally{
				DBConnection.free(rs, ps, conn);
			}
			return flag;
		}
		
		public static boolean addManager(Manager manager){
			Connection conn = null;
			PreparedStatement ps =null;
			ResultSet rs = null;
			boolean flag = false;
			try {
				conn = DBConnection.getConnection();
				String sql = "insert into tb_manager values(mrg_sequence.nextval+1,?,?) ";
				ps =conn.prepareStatement(sql);
				ps.setString(1, manager.getUname());
				ps.setString(2, manager.getUpass());
				
				int i =ps.executeUpdate();
				if(i>0){
					flag = true;
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBConnection.free(rs, ps, conn);
			}
			return flag;
		}
		
		// ɾ������
		public void deleteManager(List<Integer> managers) {
			Connection conn = null;
			PreparedStatement ps = null;

			try {
				conn = DBConnection.getConnection();
				String sql = "delete tb_manager where m_id = ?"; // in
				ps = conn.prepareStatement(sql);
				// ����ִ��
				for (int p_id : managers) {
					ps.setInt(1, p_id);
					ps.addBatch();//
				}
				ps.executeBatch();

			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.free(null, ps, conn);
				;
			}
		}
		
		// ��ѯ����
		public List<Manager> getManagerList() {
			List<Manager> managerList = new ArrayList<Manager>();
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				conn = DBConnection.getConnection();
				String sql = "select * from tb_manager";
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				while (rs.next()) {
					Manager manager= new Manager();
					manager = rsToManager(rs);
					managerList.add(manager);
				}

			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.free(rs, ps, conn);
			}
			return managerList;
		}
		
			private Manager rsToManager(ResultSet rs) throws SQLException {
				Manager manager = new Manager();
				
				manager.setM_id(rs.getInt("m_id"));
				manager.setUname(rs.getString("uname"));
			
				return manager;
			}	

}
