package com.infsci.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Member_RegisterDao {

	public static boolean Member_Register(String m_name, String m_pwd,
			String m_address, String m_kind, String m_buzkind, String m_income,
			String m_age, String m_sex, String m_marriage) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		try {
			conn = DBConnection.getConnection();

			if (m_kind.equals("Home")) {
				String sql = "insert into tb_home_ctm values(ctm_sequence.nextval,?,?,?,?,?,?,?) ";
				ps = conn.prepareStatement(sql);
				ps.setString(1, m_name);
				ps.setString(2, m_pwd);
				ps.setString(3, m_address);
				ps.setInt(7, Integer.parseInt(m_income));
				ps.setInt(6, Integer.parseInt(m_age));
				ps.setString(5, m_sex);
				ps.setString(4, m_marriage);

			} else {
				String sql = "insert into tb_buz_ctm values(ctm_sequence.nextval,?,?,?,?,?) ";
				ps = conn.prepareStatement(sql);
				ps.setString(1, m_name);
				ps.setString(2, m_pwd);
				ps.setString(3, m_address);
				ps.setString(4,m_buzkind);
				ps.setInt(5, Integer.parseInt(m_income));

			}

			int i = ps.executeUpdate();
			if (i > 0) {
				flag = true;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return flag;
	}

}
