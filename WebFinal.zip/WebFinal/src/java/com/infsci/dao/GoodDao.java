package com.infsci.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.infsci.bean.Good;

public class GoodDao {
    
	public boolean addGood(Good good) {
		boolean b = false;

		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into tb_product(p_id,p_name,kind,price,p_date,amount,pic,descrip) values(pro_sequence.nextval,?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, good.getP_name());
			ps.setString(2, good.getP_kind());
			ps.setInt(3, good.getP_price());
			ps.setDate(4, good.getP_date());
			ps.setInt(5, good.getP_amount());
			ps.setString(6, good.getP_pic());
			ps.setString(7, good.getP_descrip());

			int i = ps.executeUpdate();
			if (i == 1) {
				b = true;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
		}
		return b;
	}


	public List<Good> getGoodList() {
		List<Good> goodList = new ArrayList<Good>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from tb_product";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Good good = new Good();
				good = rsToGood(rs);
				goodList.add(good);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return goodList;
	}


	public void deleteGood(List<Integer> goods) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBConnection.getConnection();
			String sql = "delete tb_product where p_id = ?"; // in
																// (1231,3423,5345,3344)
			ps = conn.prepareStatement(sql);
			// ����ִ��
			for (int p_id : goods) {
				ps.setInt(1, p_id);
				ps.addBatch();//
			}
			ps.executeBatch();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
			;
		}
	}


	public boolean changeGood(Good good) {
		boolean b = false;

		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "update tb_product set p_name=?,kind=?,price=?,p_date=?,amount=?,pic=?,descrip=? where p_id=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, good.getP_name());
			ps.setString(2, good.getP_kind());
			ps.setInt(3, good.getP_price());
			ps.setDate(4, good.getP_date());
			ps.setInt(5, good.getP_amount());
			ps.setString(6, good.getP_pic());
			ps.setString(7, good.getP_descrip());
			ps.setInt(8, good.getP_id());

			int i = ps.executeUpdate();
			if (i == 1) {
				b = true;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
		}
		return b;
	}

	// ����������ѯ
	public Good getGoodById(int p_id) {
		Good good = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from tb_product where p_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, p_id);
			rs = ps.executeQuery();
			if (rs.next()) {
				good = rsToGood(rs);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return good;
	}

	private Good rsToGood(ResultSet rs) throws SQLException {
		Good good = new Good();

		good.setP_id(rs.getInt("p_id"));
		good.setP_name(rs.getString("p_name"));
		good.setP_kind(rs.getString("kind"));
		good.setP_price(rs.getInt("price"));
		good.setP_date(rs.getDate("p_date"));
		good.setP_amount(rs.getInt("amount"));
		good.setP_pic(rs.getString("pic"));
		good.setP_descrip(rs.getString("descrip"));

		return good;
	}


	public List<Good> getGoodByPage(int page, int pageRow) {
		List<Good> goodList = new ArrayList<Good>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int start = (page - 1) * pageRow + 1;
		int end = start + pageRow - 1;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from (select a.*,rownum as rn from (select * from tb_product) a where rownum <=?) where rn >=? ";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, end);
			ps.setInt(2, start);
			rs = ps.executeQuery();
			while (rs.next()) {
				Good good = rsToGood(rs);
				goodList.add(good);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}

		return goodList;
	}


	public int getGoodCount() {
		int count = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select count(p_id) from tb_product";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}

		return count;
	}
	
	public Good getGoodByDate() {
		Good good = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from tb_product where p_date>=all(select p_date from tb_product)";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				good = rsToGood(rs);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return good;
	}
	
	public Good getGoodByAmount() {
		Good good = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from tb_product where p_id=(select p_id from (select p_id ,sum(quantity) from tb_order  group by p_id order by sum(quantity) desc) where rownum=1)";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				good = rsToGood(rs);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return good;
	}


		
		
	

}
