package com.infsci.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.infsci.bean.Good;
import com.infsci.bean.Order;

public class OrderDao {


	public boolean addOrder(Order order) {
		boolean b = false;

		Connection conn = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		try {
			conn = DBConnection.getConnection();
			
			
			String sql1="update tb_product set amount=amount-? where p_id=?";
			ps1 = conn.prepareStatement(sql1);
			ps1.setInt(1,order.getO_amount());
			ps1.setInt(2,order.getP_id());
			ps1.executeUpdate();
			
			String sql = "insert into tb_order(o_id,c_id,p_id,quantity,o_date) values(ord_sequence.nextval,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, order.getC_id());
			ps.setInt(2, order.getP_id());
			ps.setInt(3, order.getO_amount());
			ps.setDate(4,order.getO_date());
			
            
			int i = ps.executeUpdate();
			if (i == 1) {
				b = true;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
		}
		return b;
	}

	
	
	public int getAmount(Order order) {
		int amount=0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs =null;
		try {
			conn = DBConnection.getConnection();
			String sql="select * from tb_product o where p_id=? ";
			ps = conn.prepareStatement(sql);
			ps.setInt(1,order.getP_id());
			
			
			rs = ps.executeQuery();
			if (rs.next()) {
				amount = rs.getInt("amount");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return amount;
	}

	
	
	
	
	

	public void deleteOrder(List<Integer> goods) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBConnection.getConnection();
			String sql = "delete tb_order where o_id = ?"; 		
			ps = conn.prepareStatement(sql);

			for (int p_id : goods) {
				ps.setInt(1, p_id);
				ps.addBatch();
			}
			ps.executeBatch();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
			;
		}
	}
	
	public List<Order> getOrderList() {
		List<Order> orderList = new ArrayList<Order>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select o_id,p_name,h_name,quantity,o_date,price from tb_order o,tb_product p,tb_home_ctm c where o.c_id=c.c_id and o.p_id=p.p_id";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Order order = new Order();
				order = rsToOrder(rs);
				orderList.add(order);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}
		return orderList;
	}

	private Order rsToOrder(ResultSet rs) throws SQLException {
		Order order = new Order();

		order.setO_id(rs.getInt("o_id"));
		order.setP_name(rs.getString("p_name"));
		order.setC_name(rs.getString("h_name"));
		order.setO_price(rs.getInt("price"));
		order.setO_amount(rs.getInt("quantity"));
		order.setO_date(rs.getDate("o_date"));
        order.setO_total(order.getO_amount()*order.getO_price());
		return order;
	}

	public int getOrderCount() {
		int count = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select count(o_id) from tb_order";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}

		return count;
	}

	public List<Order> getOrderByPage(int page, int pageRow) {
		List<Order> orderList = new ArrayList<Order>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int start = (page - 1) * pageRow + 1;
		int end = start + pageRow - 1;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from (select a.*,rownum as rn from (select o_id,p_name,h_name,quantity,o_date,price from tb_order o,tb_product p,tb_home_ctm c where o.c_id=c.c_id and o.p_id=p.p_id) a where rownum <=?) where rn >=? ";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, end);
			ps.setInt(2, start);
			rs = ps.executeQuery();
			while (rs.next()) {
				Order order = rsToOrder(rs);
				orderList.add(order);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}

		return orderList;
	}



public List<Order> getOrderByO_ID(int page, int pageRow,int c_id) {
	List<Order> orderList = new ArrayList<Order>();
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int start = (page - 1) * pageRow + 1;
	int end = start + pageRow - 1;
	try {
		conn = DBConnection.getConnection();
		String sql = "select * from (select a.*,rownum as rn from (select o_id,c.c_id,p_name,h_name,quantity,o_date,price from tb_order o,tb_product p,tb_home_ctm c where o.c_id=c.c_id and o.p_id=p.p_id ) a where rownum <=?) where  c_id=? and rn >=? ";
		ps = conn.prepareStatement(sql);
		ps.setInt(1, end);
		ps.setInt(2, c_id);
		ps.setInt(3, start);
		rs = ps.executeQuery();
		while (rs.next()) {
			Order order = rsToOrder(rs);
			orderList.add(order);
		}

	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBConnection.free(rs, ps, conn);
	}

	return orderList;
}

}
