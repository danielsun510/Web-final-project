package com.infsci.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.infsci.bean.Good;
import com.infsci.bean.Member;

public class Member_LoginDao {
	
	public static int Member_Login(String m_name,String m_pwd){
		Connection conn = null;
		PreparedStatement ps =null;
		ResultSet rs = null;
		int flag =0;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from tb_home_ctm where h_name =? and h_pwd =?";
			ps =conn.prepareStatement(sql);
			ps.setString(1, m_name);
			ps.setString(2, m_pwd);
			rs = ps.executeQuery();
			if(rs.next()){
				String ex_m_name =rs.getString("h_name");
				String ex_m_pwd = rs.getString("h_pwd");
				if((m_name.equals(ex_m_name))&&(m_pwd.equals(ex_m_pwd))){
					flag = rs.getInt("c_id");
				}
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConnection.free(rs, ps, conn);
		}
		return flag;
	}
	
	
	
	
	
	public void deleteCustomer(List<Integer> goods) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBConnection.getConnection();
			String sql = "delete tb_home_ctm where c_id = ?";
																// (1231,3423,5345,3344)
			ps = conn.prepareStatement(sql);
		
			for (int p_id : goods) {
				ps.setInt(1, p_id);
				ps.addBatch();
			}
			ps.executeBatch();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
			;
		}
	}
	
	public void deleteBZCustomer(List<Integer> goods) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBConnection.getConnection();
			String sql = "delete tb_buz_ctm where c_id = ?"; 
																// (1231,3423,5345,3344)
			ps = conn.prepareStatement(sql);

			for (int p_id : goods) {
				ps.setInt(1, p_id);
				ps.addBatch();//
			}
			ps.executeBatch();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(null, ps, conn);
			;
		}
	}
	
	

	public List<Member> getCustomerByPage(int page, int pageRow) {
		List<Member> memberList = new ArrayList<Member>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int start = (page - 1) * pageRow + 1;
		int end = start + pageRow - 1;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from (select a.*,rownum as rn from (select * from tb_home_ctm) a where rownum <=?) where rn >=? ";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, end);
			ps.setInt(2, start);
			rs = ps.executeQuery();
			while (rs.next()) {
				Member member = rsToMember(rs);
				memberList.add(member);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}

		return memberList;
	}
	
	public List<Member> getBZCustomerByPage(int page, int pageRow) {
		List<Member> memberList = new ArrayList<Member>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int start = (page - 1) * pageRow + 1;
		int end = start + pageRow - 1;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from (select a.*,rownum as rn from (select * from tb_buz_ctm) a where rownum <=?) where rn >=? ";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, end);
			ps.setInt(2, start);
			rs = ps.executeQuery();
			while (rs.next()) {
				Member member = rsToBZMember(rs);
				memberList.add(member);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.free(rs, ps, conn);
		}

		return memberList;
	}
	

		public int getCustomerCount() {
			int count = 0;
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
		
			try {
				conn = DBConnection.getConnection();
				String sql = "select count(c_id) from tb_home_ctm";
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				if (rs.next()) {
					count = rs.getInt(1);
				}
				
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.free(rs, ps, conn);
			}

			return count;
		}
		

				public int getBZCustomerCount() {
					int count = 0;
					Connection conn = null;
					PreparedStatement ps = null;
					ResultSet rs = null;
				
					try {
						conn = DBConnection.getConnection();
						String sql = "select count(c_id) from tb_buz_ctm";
						ps = conn.prepareStatement(sql);
						rs = ps.executeQuery();
						if (rs.next()) {
							count = rs.getInt(1);
						}
						
						
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (SQLException e) {
						e.printStackTrace();
					} finally {
						DBConnection.free(rs, ps, conn);
					}

					return count;
				}

				private Member rsToMember(ResultSet rs) throws SQLException {
					Member member=new Member();
					member.setM_id(rs.getInt("c_id"));
					member.setM_name(rs.getString("h_name"));
					member.setM_address(rs.getString("address"));
					member.setM_marriage(rs.getString("marriage"));
					member.setM_sex(rs.getString("gender"));
					member.setM_income(rs.getInt("h_income"));
					member.setM_age(rs.getInt("h_age"));
					return member;
				}
				
				private Member rsToBZMember(ResultSet rs) throws SQLException {
					Member member=new Member();
					member.setM_id(rs.getInt("c_id"));
					member.setM_name(rs.getString("b_name"));
					member.setM_address(rs.getString("address"));
                    member.setM_buzkind(rs.getString("b_buzkind"));
                    member.setM_anincome(rs.getInt("b_income"));
					return member;
				}
				
				
				
				
}
