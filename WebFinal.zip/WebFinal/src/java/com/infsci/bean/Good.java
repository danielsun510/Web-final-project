package com.infsci.bean;

import java.sql.Date;

public class Good {

	private int p_id;
	private String p_name;
	private String p_kind;
	private int   p_price;
	private Date  p_date;
	private int   p_amount;
	private String p_pic;
	private String p_descrip;
	private String s_name;
	private String st_name;

	
	
	public  Good(){
		
		
	}
	
	
	public Good(String p_name,String p_kind,int p_price,Date p_date,int p_amount,String p_pic,String p_descrip){
		this.p_name=p_name;
		this.p_kind=p_kind;
		this.p_price=p_price;
		this.p_date=p_date;
		this.p_amount=p_amount;
		this.p_pic=p_pic;
		this.p_descrip=p_descrip;
		
		
	}
	public Good(int p_id,String p_name,String p_kind,int p_price,Date p_date,int p_amount,String p_pic,String p_descrip){
		this.p_id=p_id;
		this.p_name=p_name;
		this.p_kind=p_kind;
		this.p_price=p_price;
		this.p_date=p_date;
		this.p_amount=p_amount;
		this.p_pic=p_pic;
		this.p_descrip=p_descrip;
		
		
	}

	
	public String getS_name() {
		return s_name;
	}


	public void setS_name(String s_name) {
		this.s_name = s_name;
	}


	public String getSt_name() {
		return st_name;
	}


	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}


	public int getP_id(){
		return p_id;
	}
  
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getP_name() {
		return p_name;
	}


	public void setP_name(String p_name) {
		this.p_name = p_name;
	}


	public String getP_kind() {
		return p_kind;
	}


	public void setP_kind(String p_kind) {
		this.p_kind = p_kind;
	}


	public int getP_price() {
		return p_price;
	}


	public void setP_price(int p_price) {
		this.p_price = p_price;
	}


	public Date getP_date() {
		return p_date;
	}


	public void setP_date(Date p_date) {
		this.p_date = p_date;
	}


	public int getP_amount() {
		return p_amount;
	}


	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}


	public String getP_pic() {
		return p_pic;
	}


	public void setP_pic(String p_pic) {
		this.p_pic = p_pic;
	}


	public String getP_descrip() {
		return p_descrip;
	}


	public void setP_descrip(String p_descrip) {
		this.p_descrip = p_descrip;
	}
	
	
	
}
