package com.infsci.bean;

import java.io.Serializable;

public class Manager implements Serializable {

	private int m_id;
	private String uname;
	private String upass;
	
	
	public Manager()
	{
		
	}

	public Manager(String uname, String upass) {

		this.uname = uname;
		this.upass = upass;

	}

	public Manager(int m_id, String uname, String upass) {

		this.m_id = m_id;
		this.uname = uname;
		this.upass = upass;

	}

	public int getM_id() {
		return m_id;
	}

	public void setM_id(int m_id) {
		this.m_id = m_id;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpass() {
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

}
